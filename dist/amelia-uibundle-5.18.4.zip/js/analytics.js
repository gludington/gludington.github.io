/* Main function modified to client's needs
	places triggered from:
		- ameliaActions.resetConversation
*/
function sendAnalytics(event) {}
