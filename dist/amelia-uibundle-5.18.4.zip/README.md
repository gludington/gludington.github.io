Do not delete.

This is where the index.html will be copied upon build.
